#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matriz[2][3];
    int i,j;
    for(i=0; i<2; i++)
    {
        for(j=0; j<3; j++)
        {
            printf("M[%d][%d]: ",i,j);
            scanf("%d",&matriz[i][j]);
        }
    }
    for(i=0; i<2; i++)
    {
        for(j=0; j<3; j++)// termina con la linea...columna a columna j=0;j=1;j=2;
        {
            printf("|[%d]| \t",matriz[i][j]);
        }
        printf("\n");//salta la linea y i=1;
    }
return 0;
}
