#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comercio.h"
#define TAM 3


int main()
{
    eProducto producto[TAM];

    inicializar(producto,TAM);
    char seguir='s';
    int opcion=0;

    while(seguir=='s')
    {
        printf("1- Agregar producto\n");
        printf("2- Modificar producto\n");
        printf("3- Borrar producto\n");
        printf("4- Imprimir lista\n\n");
        printf("5- Salir\n");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                alta(producto,TAM);
                break;
            case 2:
                modificar(producto,TAM);
                break;
            case 3:
                baja(producto,TAM);
                break;
            case 4:
                mostrar(producto,TAM);
                break;
            case 5:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}
