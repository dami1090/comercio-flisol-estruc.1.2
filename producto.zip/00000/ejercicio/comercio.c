#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comercio.h"


int inicializar(eProducto lista[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        lista[i].estado=0;
    }
    return 0;
}

int obtenerEspacioLibre(eProducto lista[],int tam)
{
    int i;
    int indice=-1;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado == 0)
        {
            indice=i;
            break;
        }
    }

    return indice;
}

void alta(eProducto lista[],int tam)
{

    int indice;
    indice=obtenerEspacioLibre(lista,tam);
    if(indice !=-1)
    {
        printf("ingrese codigo: \n");
        setbuf(stdin,NULL);
        scanf("%d",&lista[indice].codigo);
        printf("ingrese la descripcion: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",lista[indice].descrip);
        printf("ingrese el importe: \n");
        setbuf(stdin,NULL);
        scanf("%f",&lista[indice].importe);
        printf("ingrese el stock: \n");
        setbuf(stdin,NULL);
        scanf("%d",&lista[indice].cantidad);
        lista[indice].estado=1;
    }
    else
    {
        printf("no queda mas espacio en el sistema para seguir cargando productos!\n");
    }
    return;
}

void mostrar(eProducto lista[],int tam)
{
    int i;
    printf("codigo\t\timporte\t\tstock\n");
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            printf("%d\t\t%.2f\t\t%d\n",lista[i].codigo,lista[i].importe,lista[i].cantidad);
            printf("Descripcion: %s\n\n\n",lista[i].descrip);
        }

    }
    return;
}

int baja(eProducto lista[],int tam)
{
    int i,aux;
    int flag=0;

    printf("escriba el codigo del producto que desea dar de baja\n");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(aux==lista[i].codigo)
        {
            flag=1;
            lista[i].estado=0;
            break;
        }
    }
    if(flag!=1)
    {
        printf("el codigo: %d ,no se ha encontrado\n",aux);
    }
    else
    {
        printf("el producto ha sido dado de baja correctamente\n");
    }
    return 0;
}


int modificar(eProducto lista[],int tam)
{
    int i,aux;
    int flag=0;
    char seguir='s';
    int opcion=0;

    printf("escriba el codigo del producto que desea modificar\n");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(aux==lista[i].codigo)
        {
            flag=1;
            while(seguir=='s')
            {
                printf("1- modificar descripcion\n");
                printf("2- Modificar importe\n");
                printf("3- modificar stock\n");

                printf("4- Salir\n");

                setbuf(stdin,NULL);
                scanf("%d",&opcion);

                switch(opcion)
                {
                case 1:
                    printf("ingrese la descripcion: \n");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",lista[i].descrip);
                    break;
                case 2:
                    printf("ingrese el importe: \n");
                    setbuf(stdin,NULL);
                    scanf("%f",&lista[i].importe);
                    break;
                case 3:
                    printf("ingrese el stock: \n");
                    setbuf(stdin,NULL);
                    scanf("%d",&lista[i].cantidad);
                    break;
                case 4:
                    seguir = 'n';
                    break;

                default:
                    system("cls");
                    printf("\n\tOpcion invalida\n\n");
                    break;
                }
                system("pause");
                system("cls");
            }
        }
    }
            if(flag!=1)
            {
                printf("el codigo: %d ,no se ha encontrado\n",aux);
            }
            else
            {
                printf("el producto ha sido modificado correctamente\n");
            }
            return 0;
        }


