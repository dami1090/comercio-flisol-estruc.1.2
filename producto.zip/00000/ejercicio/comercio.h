#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct {
    int codigo;
    char descrip[501];
    float importe;
    int cantidad;
    int estado;

}eProducto;

int inicializar(eProducto lista[],int);
int obtenerEspacioLibre(eProducto lista[],int);
void alta(eProducto[],int);
void mostrar(eProducto[],int);
int baja(eProducto[],int);
int modificar(eProducto[],int);
#endif // FUNCIONES_H_INCLUDED
