#include <stdio.h>
#include <stdlib.h>
typedef struct{
int edad;
char nombre[51];
float salario;

}ePersona;
int main()
{
    int entero;
    char caracter;
    char palabra[51];
    float decimal;
    ePersona dami[5];

    entero=sizeof(entero);
    printf("int: %d\n",entero);
    entero=sizeof(caracter);
    printf("char: %d\n",entero);
    entero=sizeof(palabra);
    printf("cadena: %d\n",entero);
    entero=sizeof(decimal);
    printf("float: %d\n",entero);
    entero=sizeof(dami);
    printf("estructura persona: %d\n",entero);


    printf("Hello world!\n");
    return 0;
}
